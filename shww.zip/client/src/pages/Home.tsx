import { useState, useRef } from "react";
import { DiscordCard } from "@/components/DiscordCard";
import { RescuedUsers } from "@/components/RescuedUsers";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const [revealed, setRevealed] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const handleReveal = () => {
    if (!revealed) {
      setRevealed(true);
      if (audioRef.current) {
        audioRef.current.volume = 0.5;
        audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      }
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white overflow-hidden relative selection:bg-white selection:text-black">
      
      {/* Audio Element */}
      <audio ref={audioRef} src="/click_sound.mp3" preload="auto" loop />

      {/* Background Image Layer */}
      <div className="fixed inset-0 z-0">
        {/* Background Image Layer - Only visible after reveal */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: revealed ? 0.2 : 0 }}
          transition={{ duration: 2, ease: "easeIn" }}
          className="absolute inset-0 bg-[url('/bg.jpg')] bg-cover bg-center grayscale" 
        />
        
        {/* Overlay for readability - Always present but adjusts */}
        <div className="absolute inset-0 bg-black/80 backdrop-blur-[2px]" />
        
        {/* Subtle Noise Texture - Always present for texture */}
        <div className="absolute inset-0 opacity-[0.03]" 
             style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }} 
        />
      </div>

      <main className="relative z-10 w-full max-w-4xl px-4 flex flex-col items-center py-12 min-h-screen">
        
        {/* Doll Section - Absolute Top Center & Pendulum Animation */}
        <AnimatePresence>
          {!revealed && (
            <motion.div
              initial={{ y: -100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="absolute top-0 left-1/2 -translate-x-1/2 z-50"
            >
              <div className="relative cursor-pointer group" onClick={handleReveal}>
                {/* Pendulum Animation Wrapper */}
                <motion.div
                  style={{ originY: 0, originX: 0.5 }} // Anchor point at the very top center
                  animate={{ 
                    rotate: [3, -3], // Smoother pendulum swing
                  }}
                  transition={{ 
                    repeat: Infinity, 
                    repeatType: "mirror", // Ensures seamless back-and-forth
                    duration: 2.5, // Slightly faster for more natural gravity feel
                    ease: "easeInOut"
                  }}
                >
                  <img 
                    src="/doll.png" 
                    alt="Doll" 
                    className="w-48 md:w-64 object-contain drop-shadow-2xl grayscale hover:grayscale-0 transition-all duration-700"
                  />
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Center Content Container */}
        <div className="flex-1 flex flex-col items-center justify-center w-full">
          
          {/* Click Button - Disappears after click */}
          <AnimatePresence>
            {!revealed && (
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                onClick={handleReveal}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="mt-[500px] px-10 py-4 glass-button border border-white/20 text-white font-mono text-xs tracking-[0.4em] uppercase transition-all duration-500 hover:bg-white hover:text-black hover:shadow-[0_0_30px_rgba(255,255,255,0.3)] relative z-50"
              >
                CLICK TO REVEAL
              </motion.button>
            )}
          </AnimatePresence>

          {/* Content Grid - Appears after click */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ 
              opacity: revealed ? 1 : 0,
              y: revealed ? 0 : 20,
              pointerEvents: revealed ? "auto" : "none",
              display: revealed ? "grid" : "none"
            }}
            transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
            className="w-full flex flex-col gap-12 items-center justify-center mt-12"
          >
            {/* Left Column: Discord Card */}
            <div className="flex flex-col items-center gap-4">
              <DiscordCard />
            </div>

            {/* Right Column: TikTok Rescued Users */}
            <div className="flex flex-col items-center gap-4 w-full">
              <RescuedUsers />
            </div>
            
          </motion.div>
        </div>

      </main>
    </div>
  );
}
